import locale774aad26 from '../..\\client\\locales\\fa.js'

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
  REDIRECT_ON_OPTIONS: {"ALL":"all","ROOT":"root","NO_PREFIX":"no prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {"fallbackLocale":"fa"},
  vueI18nLoader: false,
  locales: [{"name":"فارسی","code":"fa","iso":"fa-IR","file":"fa.js","rtl":true}],
  defaultLocale: "fa",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix_except_default",
  lazy: true,
  langDir: "D:\\CODE\\Repositories\\nuxt-base\\client\\locales",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"appname.lang","cookieSecure":false,"fallbackLocale":"fa","redirectOn":"root","useCookie":true},
  differentDomains: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"name":"فارسی","code":"fa","iso":"fa-IR","file":"fa.js","rtl":true}],
  localeCodes: ["fa"],
  additionalMessages: [],
}

export const localeMessages = {
  'fa.js': () => Promise.resolve(locale774aad26),
}
