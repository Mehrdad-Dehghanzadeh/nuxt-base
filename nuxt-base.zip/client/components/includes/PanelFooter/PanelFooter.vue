<template>
  <footer class="panel-footer text-center">
    <code class=""> < footer > </code>
  </footer>
</template>

<script>
export default {
  name: 'PanelFooter',
}
</script>

<style lang="scss" src="./PanelFooter.scss" />
