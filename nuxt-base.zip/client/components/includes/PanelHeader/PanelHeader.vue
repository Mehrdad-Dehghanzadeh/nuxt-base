<template>
  <header class="panel-header text-center">
    <code> < header > </code>
  </header>
</template>

<script>
export default {
  name: 'PanelHeader',
}
</script>

<style lang="scss" src="./PanelHeader.scss" />
