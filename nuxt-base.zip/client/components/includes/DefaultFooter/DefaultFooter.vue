<template>
  <footer class="default-footer">
    <div class="text-center heading-1">
      <code> < footer > </code>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'DefaultFooter',
}
</script>

<style lang="scss" src="./DefaultFooter.scss" />
