<template>
  <header class="default-header">
    <div class="text-center heading-1">
      <code> < header > </code>
    </div>
  </header>
</template>

<script>
export default {
  name: 'DefaultHeader',
}
</script>

<style lang="scss" src="./DefaultHeader.scss"></style>
