<template>
  <main class="full-layout">
    <div class="container">
      <nuxt />
    </div>
  </main>
</template>

<script>
export default {
  name: 'FullLayout',
}
</script>

<style></style>
