export const ticketStatus = {
  pending: 'در حال انتظار',
  answered: 'پاسخ داده',
  closed: 'بسته',
}

export default {
  ticketStatus,
}
